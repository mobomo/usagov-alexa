This module is used an example module in the Acquia Drupal Module Development course.
Course can be found in Acquia Academy. https://www.acquiaacademy.com/
